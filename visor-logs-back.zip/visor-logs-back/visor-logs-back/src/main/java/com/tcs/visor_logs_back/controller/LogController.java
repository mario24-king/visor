package com.tcs.visor_logs_back.controller;

import com.tcs.visor_logs_back.entity.Log;
import com.tcs.visor_logs_back.repository.LogRepository;
import com.tcs.visor_logs_back.service.LogServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:4200") // Puerto donde corre Angular
@RestController
@RequestMapping ("/api/logs")

public class LogController {

    @Autowired
    private LogServices logService;

    @Autowired
    private LogRepository logRepository;

    @GetMapping
    public List<Log> listarTodos() {
        return logService.obtenerTodos();
    }

    @PostMapping
    public ResponseEntity<Log>
    guardar(@RequestBody Log log) {
        Log creado = logService.guardar(log);
            return  new ResponseEntity<>(creado, HttpStatus.CREATED);
    }

    @GetMapping("/search")
    public List<Log> searchLogs(@RequestParam String query) {
        return logRepository.findByUsernameContainingIgnoreCaseOrActionContainingIgnoreCaseOrDescriptionContainingIgnoreCase(query, query, query);
    }


}
