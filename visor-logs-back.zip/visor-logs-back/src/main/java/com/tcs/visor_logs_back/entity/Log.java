package com.tcs.visor_logs_back.entity;

import com.tcs.visor_logs_back.entity.Status;
import jakarta.persistence.*;
import jdk.jshell.Snippet;

import java.time.LocalDate;

@Entity
@Table(name = "visor_logs")
public class Log {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    @Column(name = "id_user")
    private Long id;

    private LocalDate date;

    private String username;

    @Enumerated(EnumType.STRING)
    private Status status;

    private String action;

    private String description;

    // Constructor vacío y constructor con parámetros

    public Log() {
    }

    public Log(Long id, LocalDate date, String username, Status status, String action, String description) {
        this.id = id;
        this.date = date;
        this.username = username;
        this.status = status;
        this.action = action;
        this.description = description;
    }

    //getters y setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}



