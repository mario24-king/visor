package com.tcs.visor_logs_back.repository;

import com.tcs.visor_logs_back.entity.Log;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface LogRepository extends JpaRepository<Log, Long> {
    List<Log> findByStatus(String status);
}

