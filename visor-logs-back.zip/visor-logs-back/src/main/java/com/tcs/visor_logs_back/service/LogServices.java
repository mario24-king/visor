package com.tcs.visor_logs_back.service;

import com.tcs.visor_logs_back.entity.Log;

import java.util.List;

public interface LogServices {
    List<Log>  obtenerTodos();
    Log guardar(Log log);
}
