package com.tcs.visor_logs_back.service;

import com.tcs.visor_logs_back.entity.Log;
import com.tcs.visor_logs_back.repository.LogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LogServicesImpl implements LogServices {

    @Autowired
    private LogRepository logRepository;

    @Override
    public List<Log> obtenerTodos () {
        return logRepository.findAll();
    }

    @Override
    public Log guardar(Log log) {
        return logRepository.save(log);
    }

}

