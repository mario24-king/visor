package com.tcs.visor_logs_back.entity;

public enum Status {
    SUCCESS,
    ERROR,
    WARNING,
    INFO,
}
