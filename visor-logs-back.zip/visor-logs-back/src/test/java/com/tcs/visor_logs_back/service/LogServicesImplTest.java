package com.tcs.visor_logs_back.service;

import com.tcs.visor_logs_back.entity.Log;
import com.tcs.visor_logs_back.entity.Status;
import com.tcs.visor_logs_back.repository.LogRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

class LogServicesImplTest {

    @Mock
    private LogRepository logRepository;

    @InjectMocks
    private LogServicesImpl logServices;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testObtenerTodos() {
        Log log1 = new Log(1L, LocalDate.now(), "mario", Status.SUCCESS, "LOGIN", "Inicio de sesión exitoso");
        Log log2 = new Log(2L, LocalDate.now(), "juan", Status.FAILURE, "LOGIN", "Contraseña incorrecta");

        when(logRepository.findAll()).thenReturn(Arrays.asList(log1, log2));

        List<Log> resultado = logServices.obtenerTodos();

        assertThat(resultado).hasSize(2);
        assertThat(resultado.get(0).getUsername()).isEqualTo("mario");
        assertThat(resultado.get(1).getUsername()).isEqualTo("juan");

        verify(logRepository, times(1)).findAll();
    }

    @Test
    void testGuardar() {
        Log log = new Log(1L, LocalDate.now(), "mario", Status.SUCCESS, "LOGIN", "Inicio de sesión exitoso");

        when(logRepository.save(log)).thenReturn(log);

        Log resultado = logServices.guardar(log);

        assertThat(resultado).isNotNull();
        assertThat(resultado.getUsername()).isEqualTo("mario");

        verify(logRepository, times(1)).save(log);
    }
}
