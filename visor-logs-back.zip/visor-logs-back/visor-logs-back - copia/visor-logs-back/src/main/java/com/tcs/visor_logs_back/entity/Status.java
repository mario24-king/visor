package com.tcs.visor_logs_back.entity;

public enum Status {
    SUCCES,
    ERROR,
    WARNING,
    INFO,
}
