export interface Customer {
  id: number;
  date: string;
  username: string;
  status: string;
  action: string;
  description: string;
}

